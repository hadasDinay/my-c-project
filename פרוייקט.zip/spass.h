#define ASCII_ZERO 48 
#define LEN_PRINT_NUM 4
#define LEN_BITS 16   
#define LEN_LINE_OCTAL 6 
#define FOURTEEN 14
#define THIRTEEN 13
#define TWELVE 12
#define START_OF_MEMORY 100  
int aoctaly_num(char arr[],char octal[]);
int codeing_label(labels *label_tabel,int j,char binary_line[]);/*מקודד את התוית ל-15 סיביות*/
char * binary_num(int c,char arr[],int len);
