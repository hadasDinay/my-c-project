#define TEN 10   
#define MIN_NUM 16384  
#define MAX_NUM 16384    
char * binary_num(int c,char arr[],int len);
